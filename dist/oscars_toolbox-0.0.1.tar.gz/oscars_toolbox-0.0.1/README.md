# oscars-toolbox
A package for helpful general algorithms I've developed. See also my PyPI page linked in the README.
